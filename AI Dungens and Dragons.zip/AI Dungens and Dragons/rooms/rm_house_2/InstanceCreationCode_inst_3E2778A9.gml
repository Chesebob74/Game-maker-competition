target_room = Room1;

target_x = 615;
target_y = 185;