target_room = rm_house_2;

target_x = 315;
target_y = 435;