target_room = rm_house_1;

target_x = 235;
target_y = 325;