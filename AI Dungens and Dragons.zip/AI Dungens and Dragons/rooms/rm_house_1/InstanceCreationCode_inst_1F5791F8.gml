target_room = Room1;

target_x = 410;
target_y = 405;