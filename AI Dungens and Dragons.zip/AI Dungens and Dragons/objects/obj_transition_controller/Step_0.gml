
/// obj_transition_controller - Step Event

switch (transition_state) {

    // =================================
    // IDLE
    // =================================
    case "none":

        fade_alpha = 0;

    break;


    // =================================
    // FADE OUT
    // =================================
    case "fade_out":

        fade_alpha += fade_speed;
        fade_alpha = min(fade_alpha, 1);

        if (fade_alpha >= 1) {

            // Change room
            room_goto(target_room);

            transition_state = "waiting";
        }

    break;


    // =================================
    // WAIT FOR ROOM CHANGE
    // =================================
    case "waiting":

        if (room == target_room) {

            // Find Kris
            var _player = instance_find(obj_player, 0);

            if (_player != noone) {

                // Set spawn position
                _player.x = target_x;
                _player.y = target_y;
            }

            // Begin fade in
            transition_state = "fade_in";
        }

    break;


    // =================================
    // FADE IN
    // =================================
    case "fade_in":

        fade_alpha -= fade_speed;
        fade_alpha = max(fade_alpha, 0);

        if (fade_alpha <= 0) {

            transition_state = "none";
            global.transitioning = false;
        }

    break;
}
