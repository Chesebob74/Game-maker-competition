global.transitioning = false;

fade_alpha = 0;
fade_speed = 0.04;

transition_state = "none";

target_room = noone;
target_x = 0;
target_y = 0;