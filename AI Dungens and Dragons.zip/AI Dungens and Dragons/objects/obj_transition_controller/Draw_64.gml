
/// obj_transition_controller - Draw GUI Event

if (fade_alpha > 0) {

    draw_set_alpha(fade_alpha);
    draw_set_color(c_black);

    draw_rectangle(
        0,
        0,
        display_get_gui_width(),
        display_get_gui_height(),
        false
    );

    // Reset drawing settings
    draw_set_alpha(1);
    draw_set_color(c_white);
}
