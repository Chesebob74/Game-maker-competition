// Fetch the 'Sans' profile from our script blueprint and attach it to this object
my_profile = character_get_profile("Toriel");
event_inherited();
