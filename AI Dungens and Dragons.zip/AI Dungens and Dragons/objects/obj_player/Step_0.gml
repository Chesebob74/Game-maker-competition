// ==========================================
// 0. DIALOGUE FREEZE SYSTEM CHECK
// ==========================================
if (!instance_exists(obj_dialogue)) {

    // 1. GET KEYBOARD INPUTS
    var _key_right = keyboard_check(vk_right) || keyboard_check(ord("D"));
    var _key_left  = keyboard_check(vk_left)  || keyboard_check(ord("A"));
    var _key_up    = keyboard_check(vk_up)    || keyboard_check(ord("W"));
    var _key_down  = keyboard_check(vk_down)  || keyboard_check(ord("S"));

    // 2. CALCULATE DIRECTION VECTOR
    var _input_x = _key_right - _key_left;
    var _input_y = _key_down - _key_up;

    // 3. DETERMINE FACING DIRECTION (Deltarune Style Multi-key Override)
    if (_input_x != 0 || _input_y != 0) {
        is_moving = true;
        
        // Prioritize the most recently pressed keys or give standard 4-way angle
        if (_input_x != 0 && _input_y == 0) {
            facing_dir = (_input_x > 0) ? 0 : 180;
        } else if (_input_y != 0 && _input_x == 0) {
            facing_dir = (_input_y > 0) ? 270 : 90;
        } else {
            // If diagonals are held, determine based on horizontal/vertical split
            if (_key_right && !_key_left) facing_dir = 0;
            if (_key_left && !_key_right) facing_dir = 180;
            if (_key_up && !_key_down)    facing_dir = 90;
            if (_key_down && !_key_up)    facing_dir = 270;
        }
    } else {
        is_moving = false;
    }

    // 4. APPLY MOVEMENT AND COLLISION
    var _move_x = _input_x * move_speed;
    var _move_y = _input_y * move_speed;

    // Move and slide along solid objects automatically
    move_and_collide(_move_x, _move_y, obj_wall);

    // 5. ANIMATION STATE MACHINE (MOVING)
    if (is_moving) {
        image_speed = 1; // Play walking animation
        
        switch (facing_dir) {
            case 0:   sprite_index = spr_kris_right; break;
            case 90:  sprite_index = spr_kris_down;  break;
            case 180: sprite_index = spr_kris_left;  break;
            case 270: sprite_index = spr_kris_up;    break;
        }
    }

} else {
    // ==========================================
    // FORCE PAUSE STATE (When dialogue runs)
    // ==========================================
    is_moving = false;
    hspeed = 0;
    vspeed = 0;
}

// 5b. ANIMATION STATE MACHINE (IDLE - Runs outside block to force clean stance transition)
if (!is_moving) {
    image_speed = 0;  // Freeze animation frames
    image_index = 0;  // Force to first frame (idle stance)
    
    switch (facing_dir) {
        case 0:   sprite_index = spr_kris_right; break;
        case 90:  sprite_index = spr_kris_up;    break;
        case 180: sprite_index = spr_kris_left;  break;
        case 270: sprite_index = spr_kris_down;  break;
    }
}


// ==========================================
// 6. ACTION & INTERACTION INPUT CHECKS
// ==========================================

// --- TESTING ACTION: SPARK D&D DIALOGUE (Spacebar) ---
if (keyboard_check_pressed(vk_space)) {
    if (instance_exists(obj_dialogue)) {
        instance_destroy(obj_dialogue);
    }
    instance_create_depth(0, 0, -9999, obj_dialogue);
    scr_ask_gemma("OK, this is Dand D and this guy rolled a 1 (the minimum) and asked a mom to check her house for an investigation, give a response as a suspicious mom");
}

// --- CHAT WITH SANS (Main Keyboard 1 OR Numpad 1) ---
if (keyboard_check_pressed(ord("1")) || keyboard_check_pressed(vk_numpad1)) {
    if (instance_exists(obj_dialogue)) {
        instance_destroy(obj_dialogue);
    }
    
    var _sans_profile = character_get_profile("Sans");
    instance_create_depth(0, 0, -9999, obj_dialogue);
    scr_ask_character_ai(_sans_profile, "The human is showing you their " + global.equipped_weapon);
}

// --- ITEM ROULETTE (Main Keyboard 2 OR Numpad 2) ---
if (keyboard_check_pressed(ord("2")) || keyboard_check_pressed(vk_numpad2)) {
    if (instance_exists(obj_dialogue)) {
        instance_destroy(obj_dialogue);
    }
    instance_create_depth(0, 0, -9999, obj_dialogue);
    scr_ask_item_roulette("Butterscotch Pie");
}

// 1. Tick down the dialogue cooldown timer if it's active
if (dialogue_cooldown > 0) {
    dialogue_cooldown--;
}

// --- WORLD ENTITY NPC INTERACTION (Z Key or Enter) ---
if (keyboard_check_pressed(ord("Z")) || keyboard_check_pressed(vk_enter)) {
    
    // Check: Only allow interaction if NO box exists AND the cooldown is at 0
    if (!instance_exists(obj_dialogue) && dialogue_cooldown == 0) {
        
        var _nearest_npc = instance_nearest(x, y, obj_character_parent);
        
        if (_nearest_npc != noone) {
            var _distance = point_distance(x, y, _nearest_npc.x, _nearest_npc.y);
            
            if (_distance <= _nearest_npc.interaction_range) {
                
                var _char_name = string_replace(object_get_name(_nearest_npc.object_index), "obj_", ""); 
                
                if (_char_name == "sans") _char_name = "Sans";
                if (_char_name == "papyrus") _char_name = "Papyrus";
                if (_char_name == "toriel") _char_name = "Toriel";
                
                var _profile = character_get_profile(_char_name);
                
                // Create the text box asset
                instance_create_depth(0, 0, -9999, obj_dialogue);
                
                if (_profile != undefined) {
                    var _player_input = "Mother toriel-Was in a coma and believes she had kids and a husband who all died, but they were imaginary and dissapeared when she woke up from the coma, wil very quickly become hostile and aggressive if the truth of her stories is questioned, she believes her kids were gifted and became world renown scientists at ages 7 and 11, very kind and will give any tier 1 and 2 object without any problem but only a maximum of twice, may give tier 3 but can not give teir 4, will let you into her house but will rush you out to go tend to her husband and kids's graves, has the kids that she kidnapped to make her own, is also in the tutorial and will give 1 of each tier 1 item in the tutorial. Will monologue once you find the kids and then run away, what will she say?"; 
                    scr_ask_character_ai(_profile, _player_input);
                } else {
                    with(obj_dialogue) {
                        initialize_ai_dialogue("* (The stranger stays completely silent...)");
                    }
                }
            }
        }
    }
}

// 2. Set the cooldown when a dialogue box is actively destroyed
// This checks if a dialogue box WAS open on this frame but got deleted by the Z input
if (instance_exists(obj_dialogue)) {
    // Keep setting the cooldown to 5 frames while the text box is alive
    dialogue_cooldown = 5; 
}


// --- PLAYER ATTACK STRATEGY (Press X to Strike) ---

if (keyboard_check_pressed(ord("X"))) {

    if (!instance_exists(obj_dialogue)) {

        var _target_mob = instance_place(x, y, obj_mob_parent);

        if (_target_mob != noone) {

            var _weapon_name = global.equipped_weapon;

            if (variable_struct_exists(global.item_database, _weapon_name)) {

                var _weapon_data = variable_struct_get(
                    global.item_database,
                    _weapon_name
                );

                var _player_atk = _weapon_data.damage;

                var _damage_to_mob = max(
                    1,
                    _player_atk - _target_mob.defense
                );

                // SAVE POSITION BEFORE ANY DESTRUCTION
                var _mob_x = _target_mob.x;
                var _mob_y = _target_mob.y;

                // Apply damage
                _target_mob.hp -= _damage_to_mob;

                // Create floating damage number
                var _dmg_num = instance_create_depth(
                    _mob_x,
                    _mob_y - 20,
                    -10000,
                    obj_floating_text
                );

                _dmg_num.text = string(_damage_to_mob);

                show_debug_message(
                    "Froggit HP: " + string(_target_mob.hp)
                );

                // Check if defeated
                if (_target_mob.hp <= 0) {

                    show_debug_message("ENEMY DEFEATED!");

                    with (_target_mob) {
                        instance_destroy();
                    }
                }

            } else {
                show_debug_message(
                    "Weapon not found: " + _weapon_name
                );
            }
        }
    }
}


// --- DEBUG SWAP TESTS (Temporary Verification Bindings) ---
if (keyboard_check_pressed(ord("M"))) {
    // MUST MATCH: Capital "M" on "Mace" from your new database layout
    global.equipped_weapon = "Mace";
    show_debug_message("System overridden: Equipped the Mace!");
}

if (keyboard_check_pressed(ord("D"))) {
    // MUST MATCH: Capital "D" on "Dagger" from your new database layout
    global.equipped_weapon = "Dagger"; 
    show_debug_message("System overridden: Equipped the Dagger!");
}

depth = -y;
