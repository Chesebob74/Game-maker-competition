// Movement Speeds
move_speed = 3; 

// Input Direction Tracking (0=Right, 90=Up, 180=Left, 270=Down)
facing_dir = 270; 
is_moving = false;

// If you have a wall/solid object, name it obj_wall
collision_object = obj_wall; 
// 1. Establish core mechanical variables directly linking to the profile
hp = global.player_profile.current_hp;
max_hp = global.player_profile.max_hp;

// 2. Set Invincibility protections
is_invincible = false;

// 3. Dynamically fetch armor defense stat from global registry to define player defense
var _armor_name = global.player_profile.equipped_armor;
var _armor_data = variable_struct_get(global.item_database, _armor_name);
defense = (_armor_data != undefined) ? _armor_data.defense : 0;
dialogue_cooldown = 0;
// --- BASE COMBAT STATS MATRIX ---
hp = 100;
max_hp = 100;
defense = 0;              // Base armor value
is_invincible = false;    // Flash tracking mask frame toggle

// Set default weapon from your ledger if not already initialized globally
if (!variable_global_exists("equipped_weapon")) {
    global.equipped_weapon = "Stick"; 
}
// Set initial spawn position
if (variable_global_exists("spawn_x")) {
    x = global.spawn_x;
    y = global.spawn_y;
}