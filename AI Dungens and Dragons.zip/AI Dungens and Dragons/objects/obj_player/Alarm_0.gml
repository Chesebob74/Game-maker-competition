// Automatically turns off hit flashing frames after a collision event takes place
is_invincible = false;