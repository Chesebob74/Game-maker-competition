target_room = Room1;
target_x = 200;
target_y = 300;