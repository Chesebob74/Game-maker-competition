if (!global.transitioning && !instance_exists(obj_dialogue)) {

    var _controller = instance_find(obj_transition_controller, 0);

    if (_controller != noone) {

        _controller.target_room = target_room;
        _controller.target_x = target_x;
        _controller.target_y = target_y;

        global.transitioning = true;
        _controller.transition_state = "fade_out";
    }
}