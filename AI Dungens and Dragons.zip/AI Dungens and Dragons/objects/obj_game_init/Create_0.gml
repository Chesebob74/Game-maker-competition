global.equipped_weapon = global.player_profile.equipped_weapon;
init_game_databases();