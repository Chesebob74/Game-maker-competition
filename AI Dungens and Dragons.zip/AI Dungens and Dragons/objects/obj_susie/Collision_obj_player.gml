if (!instance_exists(obj_game_over)) {

    // Freeze the game
    global.transitioning = true;

    // Create Game Over screen
    var _game_over = instance_create_depth(
        0, 0, -100000,
        obj_game_over
    );

    _game_over.game_over = true;
}