game_over = false;
image_xscale = 2;
image_yscale = 2;
image_alpha = 1;
image_speed = 1;
visible = true;