if (game_over) {

    // Black background
    draw_set_color(c_black);
    draw_set_alpha(1);

    draw_rectangle(
        0, 0,
        display_get_gui_width(),
        display_get_gui_height(),
        false
    );

    // Game Over text
    draw_set_font(fnt_main);
    draw_set_color(c_white);
    draw_set_halign(fa_center);
    draw_set_valign(fa_middle);

    draw_text(
        display_get_gui_width() / 2,
        display_get_gui_height() / 2 - 30,
        "YOU WON"
    );

    draw_set_color(c_gray);

    draw_text(
        display_get_gui_width() / 2,
        display_get_gui_height() / 2 + 30,
        "Press any key to exit"
    );

    // Reset drawing settings
    draw_set_color(c_white);
    draw_set_halign(fa_left);
    draw_set_valign(fa_top);
}
