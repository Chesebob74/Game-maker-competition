// This is now running from obj_mob_parent. 'other' correctly refers to the player!

// 1. Is Kris already flashing white from being hit? 
if (!other.is_invincible) {
    
    // 2. Perform the damage equation: Monster Attack minus Kris's Armor Defense
    var _final_damage = max(1, damage - other.defense);
    
    // 3. Subtract that result directly from Kris's current health 
    other.hp -= _final_damage;
    
    // 4. Instantly spawn a visual indicator at Kris's coordinate position
    var _alert = instance_create_depth(other.x, other.y - 20, -10000, obj_floating_text);
    _alert.text = "-" + string(_final_damage) + " HP!";
    
    // 5. Flip Kris's invincibility state to TRUE 
    other.is_invincible = true;
    
    // 6. Set Kris's Alarm 0 to ring in 60 frames (1 second at 60fps)
    other.alarm[0] = 60; 
}
