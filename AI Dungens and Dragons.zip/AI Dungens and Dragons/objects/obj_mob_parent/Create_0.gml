// Default fallback values. Unique child instances (like obj_froggit) 
// can rewrite mob_name in their own Create events BEFORE calling event_inherited().
if (!variable_instance_exists(id, "mob_name")) {
    mob_name = "Froggit"; 
}

var _data = variable_struct_get(global.mob_database, mob_name);
if (_data != undefined) {
    hp = _data.max_hp;
    damage = _data.damage;
    defense = _data.defense;
    encounter_text = _data.text;
} else {
    hp = 30;
    damage = 4;
    defense = 1;
    encounter_text = "A wild monster appears!";
}
