// Check if health pool is empty
if (hp <= 0) {
    // Trigger any death animations or drop logic here
    instance_destroy();
}
