alpha -= 0.02; // Fade away over time
if (alpha <= 0) instance_destroy();
