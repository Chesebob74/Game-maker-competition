draw_set_font(fnt_main);
draw_set_halign(fa_center);
draw_text_transformed_color(x, y, text, 1, 1, 0, c_red, c_red, c_orange, c_orange, alpha);
