text = "";
alpha = 1.0;
vspeed = -1.5; // Drift upwards slowly
