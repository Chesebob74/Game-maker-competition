// Only handle animation and button presses if the text has fully loaded!
if (is_ready) {
    if (array_length(text_array) == 0) { 
        instance_destroy(); 
        exit; 
    }
    
    var _target_text = text_array[current_page];

    if (char_index < string_length(_target_text)) {
        char_index += text_speed;
    }

    var _current_len = min(floor(char_index), string_length(_target_text));
    current_text = string_copy(_target_text, 1, _current_len);

    if (keyboard_check_pressed(ord("Z")) || keyboard_check_pressed(vk_enter)) {
        if (char_index < string_length(_target_text)) {
            char_index = string_length(_target_text); // Skip typewriter
        } else {
            if (current_page < array_length(text_array) - 1) {
                current_page++;
                char_index = 0;
                current_text = "";
            } else {
                instance_destroy(); // Dialogue chain ended
            }
        }
    }
}
