if (ds_map_find_value(async_load, "id") == global.gemma_request_id) {
    var _status = ds_map_find_value(async_load, "status");
    var _http_code = ds_map_find_value(async_load, "http_status");
    
    if (_status == 0 || _http_code == 200) {
        var _response_json = ds_map_find_value(async_load, "result");
        
        try {
            var _data = json_parse(_response_json);
            
            if (variable_struct_exists(_data, "candidates")) {
                var _candidates_array = _data.candidates;
                if (array_length(_candidates_array) > 0) {
                    var _first_candidate = _candidates_array[0];
                    if (variable_struct_exists(_first_candidate, "content")) {
                        var _parts_array = _first_candidate.content.parts;
                        if (array_length(_parts_array) > 0) {
                            var _first_part = _parts_array[0];
                            if (variable_struct_exists(_first_part, "text")) {
                                initialize_ai_dialogue(_first_part.text);
                                exit;
                            }
                        }
                    }
                }
            }
            
            if (variable_struct_exists(_data, "error")) {
                initialize_ai_dialogue("* (Google API Error: " + string(_data.error.message) + ")");
            } else {
                initialize_ai_dialogue("* (Connected, but returned an unreadable response format...)");
            }
        }
        catch(_exception) {
            initialize_ai_dialogue("* (Error deciphering text payload from Google...)");
        }
    } 
    else if (_status < 0) {
        initialize_ai_dialogue("* (Failed to connect to Google servers. Status: " + string(_status) + ")");
    }
}
