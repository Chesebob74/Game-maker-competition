// Only draw anything if the AI has successfully responded!
if (is_ready) {
    // Set font and alignment properties
    draw_set_font(fnt_main);
    draw_set_halign(fa_left);
    draw_set_valign(fa_top);
    draw_set_color(c_white);

    // 1. Draw the 9-sliced dialogue background box now that we have data
    draw_sprite_ext(spr_box, 0, box_x, box_y, box_width / sprite_get_width(spr_box), box_height / sprite_get_height(spr_box), 0, c_white, 1);

    // 2. Calculate coordinates and draw the typewriter text
    var _text_x = box_x - padding_x * 11;
    var _text_y = box_y - padding_y * 3;
    var _max_width = box_width - (padding_x * 2);

    draw_text_ext(_text_x, _text_y, current_text, 24, _max_width);
}
