dialogue_text = ""; 
current_text = "";
char_index = 0;
text_speed = 0.5; 
text_array = [];
current_page = 0;
is_ready = false; // Remains hidden safely until web code executes!

// Bounding dimensions 
box_width = 580;
box_height = 140;
box_x = 320;
box_y = 400;
padding_x = 25;
padding_y = 20;

text_sound = noone;

// Substring cleaner for bracket filtering []
function initialize_ai_dialogue(_ai_string) {
    var _start_pos = string_pos("[", _ai_string);
    var _end_pos = string_pos("]", _ai_string);
    
    if (_start_pos > 0 && _end_pos > _start_pos) {
        _ai_string = string_copy(_ai_string, _start_pos + 1, _end_pos - _start_pos - 1);
    }

    dialogue_text = _ai_string;
    
    // Clear array positions cleanly before appending
    text_array = [];
    var _raw_pages = string_split(dialogue_text, "*");
    for (var i = 0; i < array_length(_raw_pages); i++) {
        var _trimmed = string_trim(_raw_pages[i]);
        if (_trimmed != "") array_push(text_array, _trimmed);
    }
    
    if (array_length(text_array) == 0) {
        array_push(text_array, "...");
    }

    // Set variable flags to open step frames!
    current_page = 0;
    char_index = 0;
    current_text = "";
    is_ready = true; 
}
