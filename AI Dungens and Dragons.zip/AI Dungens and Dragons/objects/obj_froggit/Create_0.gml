mob_name = "Froggit";
event_inherited(); // This tells it to load the HP and stats from your database!
