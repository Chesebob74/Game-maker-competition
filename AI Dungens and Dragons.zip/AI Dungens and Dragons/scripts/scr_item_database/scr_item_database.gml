global.item_database = {
    // === TIER 1 ITEMS (Common / Weak - Target D20: 5+) ===
    "Stick": {
        tier: 1,
        type: "Weapon",
        dc: 5,
        damage: 1,
        heal: -1,
        defense: 0,
        speed: 0,
        flavor: "Woody with hints of earth and a certain toy cowboy."
    },

    "Candy": {
        tier: 1,
        type: "Armor / Consumable",
        dc: 5,
        damage: 0,
        heal: 1,
        defense: 0,
        speed: 0,
        flavor: "Sweet with hints of sweet and a little sugar. Delicious."
    },

    "Monster Candy": {
        tier: 1,
        type: "Consumable",
        dc: 5,
        damage: 0,
        heal: 5,
        defense: 0,
        speed: 0,
        flavor: "Has a distinct, non-human sweet flavor with hints of deliciousness."
    },

    "Old Tutu": {
        tier: 1,
        type: "Armor",
        dc: 5,
        damage: 0,
        heal: 0,
        defense: 3,
        speed: 0,
        flavor: "A dusty, swirling skirt that makes you feel strangely flamboyant. Monsters may feel bad hitting such a cutie."
    },

    // === TIER 2 ITEMS (Uncommon - Target D20: 10+) ===
    "Tough Glove": {
        tier: 2,
        type: "Weapon",
        dc: 10,
        damage: 10,
        heal: -2,
        defense: 2,
        speed: 0,
        flavor: "A worn leather glove. Good for punching your problems away. Tastes better than key."
    },

    "Cinnamon Bun": {
        tier: 2,
        type: "Consumable",
        dc: 10,
        damage: -2,
        heal: 15,
        defense: 0,
        speed: 0,
        flavor: "A sticky pastry shaped like a little bunny. Too cute to eat, almost. Tastes better than glove."
    },

    "Astronaut Food": {
        tier: 2,
        type: "Consumable",
        dc: 10,
        damage: 1,
        heal: 20,
        defense: 0,
        speed: 0,
        flavor: "Dehydrated and vacuum-sealed. Nutritious yet DEFINITELY not delicious."
    },

    // === TIER 3 ITEMS (Rare / Strong - Target D20: 15+) ===
    "Dagger": {
        tier: 3,
        type: "Weapon",
        dc: 15,
        damage: 20,
        heal: -40,
        defense: 0,
        speed: 0,
        flavor: "Perfect for cutting pumpkins and more. Tastes sharp and ouchie."
    },

    "Copper armor": {
        tier: 3,
        type: "Armor",
        dc: 15,
        damage: 0,
        heal: 15,
        defense: 20,
        speed: 0,
        flavor: "Very good for hot weather. Conducts heat away, making cooling down easier. Tastes metallic, just like key."
    },

    "Bandage": {
        tier: 3,
        type: "Consumable",
        dc: 15,
        damage: -40,
        heal: 40,
        defense: 0,
        speed: 0,
        flavor: "That's... the wrong way to... you know what, sure. It tastes like bland fabric with a chemical, overly sterile aftertaste. Tastes worse than key."
    },

    // === TIER 4 ITEMS (Legendary / OP - Target D20: 19+) ===
    "Mace": {
        tier: 4,
        type: "Weapon",
        dc: 19,
        damage: 80,
        heal: -80,
        defense: 0,
        speed: 0,
        flavor: "Here it is. A blunt, heavy ball with really sharp spikes. Very satisfying for the male gaze. Tastes like grave."
    },

    "Butterscotch Pie": {
        tier: 4,
        type: "Consumable",
        dc: 19,
        damage: -30,
        heal: 999,
        defense: 0,
        speed: 0,
        flavor: "Freshly baked and still warm. Instantly restores your soul and heart to perfect condition. Tastes way better than key."
    }
};
