/// @function init_game_databases()
/// @description Forces all dynamic item, monster, and profile registries into global system memory at boot time.
function init_game_databases() {
    
    // 1. Core Monster Stat Blueprint Registry
    global.mob_database = {
        "Froggit":  { max_hp: 30, damage: 4, defense: 1, text: "A wild Froggit attacks!" },
        "Whimsun":  { max_hp: 20, damage: 3, defense: 0, text: "A timid Whimsun jumps out!" },
        "Loox":     { max_hp: 50, damage: 6, defense: 2, text: "Loox blocks your way!" },
        "Vegetoid": { max_hp: 45, damage: 5, defense: 3, text: "Vegetoid sprouts up!" }
    };

    // 3. NPC Character AI Profiles Matrix
    global.character_database = {
        "Papyrus": { name: "Papyrus", traits: "Enthusiastic, Bold, Naive, Confident, Kindhearted", style: "Speaks in loud ALL-CAPS. Uses lots of exclamation marks. Constantly says 'NYEH HEH HEH!' and addresses the player as 'HUMAN!'. Never uses lowercase letters.", motive: "Wants desperately to join the Royal Guard but is too sweet to hurt anyone. Obsessed with spaghetti." },
        "Sans": { name: "Sans", traits: "Laid-back, Cryptic, Cynical, Protective, Witty", style: "Speaks entirely in lowercase. Uses lazy, casual punctuation. Constantly drops skeleton puns and breaks the fourth wall.", motive: "A lazy skeleton who secretly monitors timelines and keeps an eye on the human player." },
        "Toriel": { name: "Toriel", traits: "Maternal, Gentle, Protective, Sorrowful, Warm", style: "Polite, formal, and deeply comforting. Uses endearing terms like 'My child' or 'Dear one'.", motive: "The former queen who protects fallen human children from the dangers of the Underground." }
    };
}
