{
  "$GMScript":"v1",
  "%Name":"scr_mob_database",
  "isCompatibility":false,
  "isDnD":false,
  "name":"scr_mob_database",
  "parent":{
    "name":"AI Dungens and Dragons",
    "path":"AI Dungens and Dragons.yyp",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}