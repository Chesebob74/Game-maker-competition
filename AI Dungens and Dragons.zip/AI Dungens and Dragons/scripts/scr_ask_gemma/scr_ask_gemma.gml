/// @function scr_ask_gemma(prompt)
/// @description Sends a prompt directly to Google's Gemini cloud API.
/// @param {string} prompt The text prompt for the AI.
function scr_ask_gemma(_prompt) {
    var _api_key = "AQ.Ab8RN6KYRXWaEIB-hPyPxXgv05CwL73X-cK2RwGi9SmmC-fFCQ"; 

    // Explicitly forcing Gemini to be very brief (under 15 words)
    var _system_instruction = " Keep the response under 50 words total, and pretend you are a person, just answer like your a person, just write dialogue don't speak to me as a user, but as a charcter, a roleplay, don't show thinking process settle on one responce, and write it in brackets, just words";

    var _contents_struct = {
        parts: [
            {
                text: _prompt + _system_instruction
            }
        ]
    };
    
    var _payload = {
        contents: [_contents_struct]
    };
    
    var _json_string = json_stringify(_payload);

    var _headers = ds_map_create();
    ds_map_add(_headers, "Content-Type", "application/json");

    var _model = "gemini-3.5-flash-lite";
	var _url = "https://generativelanguage.googleapis.com/v1beta/models/" + _model + ":generateContent?key=" + _api_key;
    global.gemma_request_id = http_request(_url, "POST", _headers, _json_string);

    ds_map_destroy(_headers);
}
