/// @function scr_ask_character_ai(npc_profile_struct, user_message_string)
/// @description Packages character data and user input, then fires an async HTTP request to the Gemini AI server handled by obj_dialogue.
function scr_ask_character_ai(_profile, _message) {
    var _api_key = "AQ.Ab8RN6KYRXWaEIB-hPyPxXgv05CwL73X-cK2RwGi9SmmC-fFCQ"; 

    // 1. Flatten all data explicitly into a single base prompt string variable just like the working version
    var _compiled_prompt = "Roleplay Profile:\n" +
                           "- Character Name: " + string(_profile.name) + "\n" +
                           "- Traits: " + string(_profile.traits) + "\n" +
                           "- Speaking Style Rules: " + string(_profile.style) + "\n" +
                           "- Motive: " + string(_profile.motive) + "\n\n" +
                           "Situation / Player Input: " + string(_message) + "\n\n";

    var _system_instruction = " Keep the response under 50 words total, and pretend you are a person, just answer like your a person, just write dialogue don't speak to me as a user, but as a charcter, a roleplay, don't show thinking process settle on one responce, and write it in brackets, just words";

    // 2. Build the contents matrix structure matching your working layout exactly
    var _contents_struct = {
        parts: [
            {
                text: _compiled_prompt + _system_instruction
            }
        ]
    };
    
    var _payload = {
        contents: [_contents_struct]
    };
    
    var _json_string = json_stringify(_payload);

    var _headers = ds_map_create();
    ds_map_add(_headers, "Content-Type", "application/json");

    var _model = "gemini-3.5-flash-lite";
    var _url = "https://generativelanguage.googleapis.com/v1beta/models/" + _model + ":generateContent?key=" + _api_key;
    
    global.gemma_request_id = http_request(_url, "POST", _headers, _json_string);

    ds_map_destroy(_headers);
}
