/// @function scr_ask_item_roulette(item_name)
/// @description Simulates an Undertale item roll based on D20 database requirements using Gemini 3.5.
/// @param {string} _item_name The item the player is trying to obtain.
function scr_ask_item_roulette(_item_name) {
    // 1. Using your updated Google API Key
    var _api_key = "AQ.Ab8RN6KYRXWaEIB-hPyPxXgv05CwL73X-cK2RwGi9SmmC-fFCQ"; 

    // 2. Look up the item data from your global ledger database
    var _item_data = variable_struct_get(global.item_database, _item_name);
    var _tier = 1;
    var _target = 5;
    
    if (_item_data != undefined) {
        _tier = _item_data.tier;
    }
    
    // Map the target rolls natively based on Part 5 definitions
    switch (_tier) {
        case 1: _target = 5; break;
        case 2: _target = 10; break;
        case 3: _target = 15; break;
        case 4: _target = 19; break;
    }
    
    // 3. Roll the dice inside GML first so we can give the precise context state to the AI
    var _dice_roll = irandom_range(1, 20);
    var _result = (_dice_roll >= _target) ? "GRANTED" : "DENIED";

    // 4. Build the structured prompt context string
    var _prompt = "You are an Undertale shopkeeper character. A player just rolled a D20 to get the item: '" + _item_name + "'.\n" +
                  "Target Needed: " + string(_target) + "\n" +
                  "Actual Roll: " + string(_dice_roll) + "\n" +
                  "Result: " + _result + "\n\n";

    // Your exact stylistic and structural formatting instructions
    var _system_instruction = " Keep the response under 50 words total, and pretend you are a person, just answer like you're a person, just write dialogue don't speak to me as a user, but as a character, a roleplay, don't show thinking process settle on one response, and write it in brackets, just words. Use '*' for dialogue page breaks if needed.";

    var _contents_struct = {
        parts: [
            {
                text: _prompt + _system_instruction
            }
        ]
    };
    
    var _payload = {
        contents: [_contents_struct]
    };
    
    var _json_string = json_stringify(_payload);

    var _headers = ds_map_create();
    ds_map_add(_headers, "Content-Type", "application/json");

    // 5. Blazing fast, low-latency Gemini 3.5 Flash-Lite model endpoint
    var _model = "gemini-3.5-flash-lite";
    var _url = "https://generativelanguage.googleapis.com/v1beta/models/" + _model + ":generateContent?key=" + _api_key;
    
    global.gemma_request_id = http_request(_url, "POST", _headers, _json_string);

    ds_map_destroy(_headers);
}
