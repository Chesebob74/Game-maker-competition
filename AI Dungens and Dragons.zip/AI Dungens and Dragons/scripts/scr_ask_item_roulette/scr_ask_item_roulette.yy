{
  "$GMScript":"v1",
  "%Name":"scr_ask_item_roulette",
  "isCompatibility":false,
  "isDnD":false,
  "name":"scr_ask_item_roulette",
  "parent":{
    "name":"AI Dungens and Dragons",
    "path":"AI Dungens and Dragons.yyp",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}