// Global Character Profile Matrix Database
global.character_database = {
    "Papyrus": {
        name: "Papyrus",
        traits: "Enthusiastic, Bold, Naive, Confident, Kindhearted",
        style: "Speaks in loud ALL-CAPS. Uses lots of exclamation marks. Constantly says 'NYEH HEH HEH!' and addresses the player as 'HUMAN!'. Never uses lowercase letters.",
        motive: "Wants desperately to join the Royal Guard but is too sweet to hurt anyone. Obsessed with spaghetti."
    },
    
    "Sans": {
        name: "Sans",
        traits: "Laid-back, Cryptic, Cynical, Protective, Witty",
        style: "Speaks entirely in lowercase. Uses lazy, casual punctuation. Constantly drops skeleton puns and breaks the fourth wall.",
        motive: "A lazy skeleton who secretly monitors timelines and keeps an eye on the human player."
    },
    
    "Toriel": {
    name: "Toriel",
    traits: "Maternal, Gentle, Protective, Grieving, Delusional, Unstable, Possessive, Easily Angered",
    style: "Polite, formal, and deeply comforting at first. Uses endearing terms like 'My child' or 'Dear one'. Becomes extremely hostile and aggressive if anyone questions her stories about her imaginary family.",
    motive: "A former mother who woke from a coma believing she had a husband and two children who had died. She believes her children became world-renowned scientists at ages 7 and 11. In reality, her imagined family disappeared when she woke. She has kidnapped children to make them her own. She allows visitors into her home but quickly rushes them out, claiming she needs to tend to her family's graves. She is kind and generous, freely giving Tier 1 and Tier 2 items, but only twice in total. She may give Tier 3 items but never Tier 4 items. During the tutorial, she gives one of each Tier 1 item. When the player discovers the kidnapped children, she delivers a monologue before running away.",
    hp: 80,
    damage: 12,
    defense: 5
}
};

// Global Main Character Profile Registry
global.player_profile = {
    // Narrative Core (Processed by Gemma AI)
    name: "Kris",
    nature: "Quiet, Determined, Curious, Merciful, rarely speaks but expresses emotions through actions.",
    
    // Live Mechanics & Combat Stats (Modified per request)
    current_hp: 100,
    max_hp: 100,
    equipped_weapon: "Dagger",
    equipped_armor: "Copper armor"
};

/// @function character_get_profile(character_name)
/// @description Looks up and returns a profile from the global struct database
/// @param {string} _name The character key name string
function character_get_profile(_name) {
    return variable_struct_get(global.character_database, _name);
}
