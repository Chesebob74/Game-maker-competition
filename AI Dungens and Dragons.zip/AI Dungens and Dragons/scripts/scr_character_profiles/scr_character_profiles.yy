{
  "$GMScript":"v1",
  "%Name":"scr_character_profiles",
  "isCompatibility":false,
  "isDnD":false,
  "name":"scr_character_profiles",
  "parent":{
    "name":"AI Dungens and Dragons",
    "path":"AI Dungens and Dragons.yyp",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}